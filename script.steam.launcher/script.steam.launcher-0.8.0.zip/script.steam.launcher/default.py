import os, sys, re
import xbmcaddon
import subprocess
import xbmc, xbmcgui
import shutil

# Shared resources
addonPath = ''
addon = xbmcaddon.Addon(id='script.steam.launcher')
addonPath = addon.getAddonInfo('path')

BASE_RESOURCE_PATH = os.path.join(addonPath, "resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )

from util import *
import util

__settings__   = xbmcaddon.Addon(id='script.steam.launcher')

#c_ipaddr = __settings__.getSetting("cti_server")
#c_port = __settings__.getSetting("cti_port")
steamLinux = __settings__.getSetting("SteamLinux")
xbmcLinux = __settings__.getSetting("XbmcLinux")
steamWin = __settings__.getSetting("SteamWin")
xbmcWin = __settings__.getSetting("XbmcWin")

def getAddonDataPath():
	path = ''
			
	path = xbmc.translatePath('special://profile/addon_data/%s' %(SCRIPTID))
		
	if not os.path.exists(path):
		try:
			os.makedirs(path)
		except:
			path = ''	
	return path


def getAddonInstallPath():
	path = ''
				
	path = __addon__.getAddonInfo('path')
	
	return path


def copyLauncherScriptsToUserdata():
	
	oldBasePath = os.path.join(util.getAddonInstallPath(), 'resources', 'scripts')
	newBasePath = os.path.join(util.getAddonDataPath(), 'scripts')
	
	oldPath = os.path.join(oldBasePath, 'steam-launch.bat')
	newPath = os.path.join(newBasePath, 'steam-launch.bat')
	copyScriptsFolder(newPath)
	copyFile(oldPath, newPath)
	
	oldPath = os.path.join(oldBasePath, 'SteamLauncher-AHK.ahk')
	newPath = os.path.join(newBasePath, 'SteamLauncher-AHK.ahk')
	copyFile(oldPath, newPath)
	
	oldPath = os.path.join(oldBasePath, 'SteamLauncher-AHK.exe')
	newPath = os.path.join(newBasePath, 'SteamLauncher-AHK.exe')
	copyFile(oldPath, newPath)
		
	oldPath = os.path.join(oldBasePath, 'LaunchHidden.vbs')
	newPath = os.path.join(newBasePath, 'LaunchHidden.vbs')
	copyFile(oldPath, newPath)
		
	oldPath = os.path.join(oldBasePath, 'steam-launch.sh')
	newPath = os.path.join(newBasePath, 'steam-launch.sh')
	copyFile(oldPath, newPath)
	
def copyFile(oldPath, newPath):
#	Logutil.log('new path = %s' %newPath, util.LOG_LEVEL_INFO)
	newDir = os.path.dirname(newPath)
	if not os.path.isdir(newDir):
#		Logutil.log('create directory: %s' %newDir)
		try:
			os.mkdir(newDir)
			return
		except Exception, (exc):
#			Logutil.log('Error creating directory: %s' %newDir)
			return
	
	if not os.path.isfile(newPath):
#		Logutil.log('copy launch scripts from %s to %s' %(oldPath, newPath), util.LOG_LEVEL_INFO)
		try:
			shutil.copy2(oldPath, newPath)
		except:
#			Logutil.log('Error copying launch scripts from %s to %s' %(oldPath, newPath), util.LOG_LEVEL_ERROR)
			return

def copyScriptsFolder(newPath):
	newDir = os.path.dirname(newPath)
	if not os.path.isdir(newDir):
#		Logutil.log('create directory: %s' %newDir)
		try:
			os.mkdir(newDir)
		except:
			return

copyLauncherScriptsToUserdata()
basePath = os.path.join(util.getAddonDataPath(), 'scripts')			


if os.name == 'nt':
	pass # Windows
	cmd = os.path.join(basePath, 'SteamLauncher-AHK.exe')
	print(cmd +"\""+steamWin+"\""+" "+"\""+xbmcWin+"\"")

	subprocess.Popen(cmd +"\""+steamWin+"\""+" "+"\""+xbmcWin+"\"", shell=True)
#	subprocess.Popen('cscript //B //Nologo "%appdata%/XBMC/addons/script.steam.launcher/resources/scripts/launchhidden.vbs" "%appdata%/XBMC/addons/script.steam.launcher/resources/scripts/steam-launch.bat"', shell=True)

else:
	pass # other (unix)
#	cmd = os.path.join(basePath, 'steam-launch.sh ') +cmd
#	steamLinuxCommand = print("\""+steamLinux+"\"")
#	xbmcLinuxCommand = print("\""+xbmcLinux+"\"")
	cmd = os.path.join(basePath, 'steam-launch.sh ')
	print(cmd +"\""+steamLinux+"\""+" "+"\""+xbmcLinux+"\"")

	subprocess.Popen(cmd +"\""+steamLinux+"\""+" "+"\""+xbmcLinux+"\"", shell=True)
#	subprocess.Popen(os.path.join(basePath, 'steam-launch.sh') '%s') % (steamLinux, xbmcLinux)
#	copyLauncherScriptsToUserdata() #(settings)
#	subprocess.Popen('special://profile/addon_data/
#	os.system('chmod +x $HOME/.xbmc/addons/script.steam.launcher/resources/scripts/steam-launch.sh && #$HOME/.xbmc/addons/script.steam.launcher/resources/scripts/steam-launch.sh')

#	subprocess.Popen(os.path.join(addonPath, "resources" , 'applaunch.sh ')