import os
os.system('"%appdata%/XBMC/addons/script.SteamLauncher/resources/applaunch-vbs.bat"')
os.system('$HOME/.xbmc/addons/script.SteamLauncher/resources/applaunch.sh steam -bigpicture')

