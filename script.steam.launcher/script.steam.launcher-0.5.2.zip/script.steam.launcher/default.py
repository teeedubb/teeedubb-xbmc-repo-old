import os
import subprocess

if os.name == 'nt':
	pass # Windows
	subprocess.Popen('cscript //B //Nologo "%appdata%/XBMC/addons/script.steam.launcher/resources/scripts/launchhidden.vbs" "%appdata%/XBMC/addons/script.steam.launcher/resources/scripts/steam-launch.bat"', shell=True)

else:
    pass # other (unix)
    os.system('chmod +x $HOME/.xbmc/addons/script.steam.launcher/resources/scripts/steam-launch.sh && $HOME/.xbmc/addons/script.steam.launcher/resources/scripts/steam-launch.sh')