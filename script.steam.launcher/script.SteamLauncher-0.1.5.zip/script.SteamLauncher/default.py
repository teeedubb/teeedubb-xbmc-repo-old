import os
os.system('cscript //B //Nologo "%appdata%/XBMC/addons/script.SteamLauncher/resources/launchhidden.vbs" "%appdata%/XBMC/addons/script.SteamLauncher/resources/applaunch-vbs.bat"')
os.system('$HOME/.xbmc/addons/script.SteamLauncher/resources/applaunch.sh steam -bigpicture')

