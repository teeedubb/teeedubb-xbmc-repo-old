Steam Launcher - Start Steam Big Picture Mode from within Kodi
See Kodi thread for more details:
http://forum.kodi.tv/showthread.php?tid=157499

https://github.com/teeedubb
http://store.steampowered.com/bigpicture
http://kodi.tv/