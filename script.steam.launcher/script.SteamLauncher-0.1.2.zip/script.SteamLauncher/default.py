import os
os.system('"%appdata%/XBMC/addons/script.SteamLauncher/resources/scripts/applaunch-vbs.bat"')
os.system('$HOME/.xbmc/addons/script.SteamLauncher/resources/scripts/applaunch.sh steam -bigpicture')

