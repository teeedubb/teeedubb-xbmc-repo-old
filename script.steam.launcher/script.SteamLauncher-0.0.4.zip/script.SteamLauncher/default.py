import os
os.system('C:\emulation\emulators\steam-launcher.bat')
os.system('killall -9 xbmc.bin && steam -bigpicture && sleep 5 && xbmc-standalone')