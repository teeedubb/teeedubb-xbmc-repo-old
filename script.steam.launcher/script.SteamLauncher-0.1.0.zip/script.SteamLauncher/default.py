import os
os.system('"%appdata%/XBMC/addons/script.SteamLauncher/resources/scripts/applaunch-vbs.bat"')
os.system('killall -9 xbmc.bin && steam -bigpicture')

