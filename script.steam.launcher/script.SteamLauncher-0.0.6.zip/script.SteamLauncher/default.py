import os
os.system('taskkill /f /IM XBMC.exe && timeout 1 && E:\Steam\steam.exe -bigpicture')
os.system('killall -9 xbmc.bin && steam -bigpicture && sleep 5 && xbmc-standalone')