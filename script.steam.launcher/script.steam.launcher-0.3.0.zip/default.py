import os
if os.name == 'nt':
    pass # Windows
    os.system('"%appdata%/XBMC/addons/script.steam.launcher/resources/scripts/SteamLauncher-AHK.exe" "c:\Program Files (x86)\Steam\steam.exe" "c:\Program Files (x86)\XBMC\XBMC.exe"')
else:
    pass # other (unix)
    os.system('$HOME/.xbmc/addons/script.steam.launcher/resources/steam-launch.sh')