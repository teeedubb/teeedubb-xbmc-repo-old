Steam Launcher - Start Steam Big Picture Mode from within XBMC

https://github.com/teeedubb
http://forum.xbmc.org/showthread.php?tid=157499
http://store.steampowered.com/bigpicture
http://xbmc.org/