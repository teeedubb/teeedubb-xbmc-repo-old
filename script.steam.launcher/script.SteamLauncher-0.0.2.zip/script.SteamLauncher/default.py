import os
os.system('C:\emulation\emulators\steam-launcher.bat')
