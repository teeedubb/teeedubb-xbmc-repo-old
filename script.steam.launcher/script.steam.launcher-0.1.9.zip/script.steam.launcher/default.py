import os
os.system('cscript //B //Nologo "%appdata%/XBMC/addons/script.steam.launcher/resources/launchhidden.vbs" "%appdata%/XBMC/addons/script.steam.launcher/resources/steam-launch.bat"')
os.system('$HOME/.xbmc/addons/script.steam.launcher/resources/steam-launch.sh')

